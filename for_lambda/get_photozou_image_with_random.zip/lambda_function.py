def lambda_handler(event, context):
    import requests
    import random
    target = event['target']
    base_url = 'https://api.photozou.jp/rest/search_public.json?keyword='
    url = base_url + target
    images = requests.get(url).json()['info']['photo']
    image = images[random.randrange(len(images))]
    return {'url': image['image_url']}
