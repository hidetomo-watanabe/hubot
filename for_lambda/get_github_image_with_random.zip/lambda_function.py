def lambda_handler(event, context):
    import requests
    import random
    target = 'gakky'
    base_url = 'https://api.github.com/repos/hidetomo-watanabe/image_files/contents/'
    url = base_url + target
    images = requests.get(url).json()
    image = images[random.randrange(len(images))]
    return {'url': image['download_url']}
